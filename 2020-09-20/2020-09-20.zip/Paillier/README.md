1. `paillier cryptosystem.md` 是从别人的博客里摘出来的，里面的推导存在一些小问题，有些证明有点迂回。

2. ZER0-Nu1L 自己写的内容：[Paillier 公钥密码系统](https://www.zer0-nu1l.com/2020/09/20/paillier%20crypto/#more) 
   因为发布在博客上面，对 LaTeX 公式进行了各种转义，用普通的 Markdown 编辑器打开，会出很多问题，所以就没有把源文件放在文件夹里。